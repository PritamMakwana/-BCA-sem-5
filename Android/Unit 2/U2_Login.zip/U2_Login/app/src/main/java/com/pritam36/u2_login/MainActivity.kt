package com.pritam36.u2_login

import android.content.Intent
import android.os.Bundle
import android.text.Layout
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn:Button = findViewById(R.id.btn_submit)
        val userName:EditText = findViewById(R.id.et_uname)
        val password:EditText = findViewById(R.id.et_pwd)

        btn.setOnClickListener(){
            if(userName.getText().toString()=="pritam" && password.getText().toString()=="admin") {
                val intent = Intent(this, InfoActivity::class.java)
                intent.putExtra("Username", userName.getText().toString())
                intent.putExtra("Password", password.getText().toString())
                startActivity(intent)
            }else{

                Toast.makeText(applicationContext,"User Name OR password is incorrent",Toast.LENGTH_SHORT).show()

            }
        }

    }
}
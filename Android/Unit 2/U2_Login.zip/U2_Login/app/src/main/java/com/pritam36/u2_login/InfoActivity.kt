package com.pritam36.u2_login

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.snackbar.Snackbar

class InfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info)

        val layout:LinearLayout = findViewById(R.id.infoactivity)
        Snackbar.make(layout, "Information Show", Snackbar.LENGTH_SHORT).show()

        val tv_uname:TextView = findViewById(R.id.tv_username)
        val tv_pass:TextView = findViewById(R.id.tv_password)
        val btn_back:Button = findViewById(R.id.btn_back)
        val btn_web:Button = findViewById(R.id.btn_web)

        btn_web.setOnClickListener(){
            val webintent:Intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.kscpac.org/"))
            startActivity(webintent)
        }

        var strUser = intent.getStringExtra("Username")
        var strPassword = intent.getStringExtra("Password")

        tv_uname.setText("User name : " + strUser)
        tv_pass.setText("Password name : " + strPassword)

        btn_back.setOnClickListener(){
            val myintent:Intent = Intent(applicationContext, MainActivity::class.java)
           startActivity(myintent)
        }

    }
}
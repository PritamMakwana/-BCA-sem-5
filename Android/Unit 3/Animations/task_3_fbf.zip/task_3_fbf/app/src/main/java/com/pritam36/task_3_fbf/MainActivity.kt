package com.pritam36.task_3_fbf

import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var x = 50f
    private var y = 50f
    private var xVelocity = 5f
    private var yVelocity = 5f
    private var ballWidth = 0f
    private var ballHeight = 0f
    private var screenWidth = 0f
    private var screenHeight = 0f
    private var ballAnimation: AnimationDrawable? = null
    private lateinit var ballView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ballView = findViewById(R.id.ballView)
        ballView.post {
            ballWidth = ballView.width.toFloat()
            ballHeight = ballView.height.toFloat()
            screenWidth = ballView.rootView.width.toFloat()
            screenHeight = ballView.rootView.height.toFloat() - 100f
            ballAnimation = ballView.background as AnimationDrawable
            ballAnimation!!.start()
            startMovingBall()
        }
    }

    private fun startMovingBall() {
        ballView.post {
            x += xVelocity
            y += yVelocity

            if (x + ballWidth > screenWidth || x < 0) {
                xVelocity = -xVelocity
                changeBallColor()

            }
            if (y + ballHeight > screenHeight || y < 0) {
                yVelocity = -yVelocity
                changeBallColor()
            }

            ballView.x = x
            ballView.y = y

            startMovingBall()
        }
    }

    private fun changeBallColor() {
        if (ballView.background == ContextCompat.getDrawable(this,R.drawable.red_ball)) {
            ballView.setBackgroundResource(R.drawable.blue_ball)
            val animation = ballView.background as AnimationDrawable
            animation.start()
        }
        else{
            ballView.setBackgroundResource(R.drawable.red_ball)
            val animation = ballView.background as AnimationDrawable
            animation.start()
        }


    }
}
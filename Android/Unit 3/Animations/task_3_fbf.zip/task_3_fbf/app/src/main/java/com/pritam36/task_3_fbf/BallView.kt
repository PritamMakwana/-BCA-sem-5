package com.bvh.fbf_task3

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.AnimationDrawable
import android.util.AttributeSet
import android.view.View
import com.pritam36.task_3_fbf.R

class BallView constructor(
    context: Context, attrs:AttributeSet?=null, defStyleAttr:Int=0): View(context,attrs,defStyleAttr
){
        private val redBallAnimation=context.getDrawable(R.drawable.red_ball) as AnimationDrawable
        private val blueBallAnimation=context.getDrawable(R.drawable.blue_ball) as AnimationDrawable
        private var x: Float = 50f
        private var y: Float = 50f


    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        if(x>=width-50 && y>=height-50 )
        {
            blueBallAnimation.setBounds(x.toInt()-50,y.toInt()-50,x.toInt()+50,y.toInt()+50)
            if (canvas != null) {
                blueBallAnimation.draw(canvas)
            }
            if(!blueBallAnimation.isRunning)
            {
                blueBallAnimation.start()
            }
        }
        else
        {
            redBallAnimation.setBounds(x.toInt()-50,y.toInt()-50,x.toInt()+50,y.toInt()+50)
            if (canvas != null) {
                redBallAnimation.draw(canvas)
            }
            if(!redBallAnimation.isRunning)
            {
                redBallAnimation.start()
            }
        }
    }
    fun updateBallPosition(x:Float,y:Float)
    {
        this.x=x
        this.y=y
        invalidate()
    }
}
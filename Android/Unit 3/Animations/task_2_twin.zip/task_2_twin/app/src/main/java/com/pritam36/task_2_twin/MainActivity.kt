package com.pritam36.task_2_twin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var textView: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.text_view)

        val bounce: Button = findViewById(R.id.bounce)
        bounce.setOnClickListener {
            startAnimation(R.anim.bounce)
        }

        val rotate: Button = findViewById(R.id.rotate)
        rotate.setOnClickListener {
            startAnimation(R.anim.rotate)
        }

        val scale: Button = findViewById(R.id.scale)
        scale.setOnClickListener {
            startAnimation(R.anim.scale)
        }

        val translate: Button = findViewById(R.id.translate)
        translate.setOnClickListener {
            startAnimation(R.anim.translate)
        }
    }

    private fun startAnimation(animation: Int) {
        val anim = AnimationUtils.loadAnimation(this, animation)
        textView.startAnimation(anim)
    }
}
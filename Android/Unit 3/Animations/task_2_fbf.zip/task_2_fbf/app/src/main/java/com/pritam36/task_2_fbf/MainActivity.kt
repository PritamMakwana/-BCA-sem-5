package com.pritam36.task_2_fbf

import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val animationView: ImageView = findViewById(R.id.animation_view)
        animationView.setBackgroundResource(R.drawable.dance_gif)
        val animation = animationView.background as AnimationDrawable

        val danceButton: Button = findViewById(R.id.dance_button)
        danceButton.setOnClickListener {
            animationView.setBackgroundResource(R.drawable.dance_gif)
            val animation = animationView.background as AnimationDrawable
            animation.start()
        }

        val walkButton: Button = findViewById(R.id.walk_button)
        walkButton.setOnClickListener {
            animationView.setBackgroundResource(R.drawable.walk_gif)
            val animation = animationView.background as AnimationDrawable
            animation.start()
        }

        val jumpButton: Button = findViewById(R.id.jump_button)
        jumpButton.setOnClickListener {
            animationView.setBackgroundResource(R.drawable.jump_gif)
            val animation = animationView.background as AnimationDrawable
            animation.start()
        }

        val runButton: Button = findViewById(R.id.run_button)
        runButton.setOnClickListener {
            animationView.setBackgroundResource(R.drawable.run_gif)
            val animation = animationView.background as AnimationDrawable
            animation.start()
        }

    }
}
package com.pritam36.task_1_twin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val ball: ImageView = findViewById(R.id.ball)
        val animation = AnimationUtils.loadAnimation(this, R.anim.bounce)
        ball.startAnimation(animation)
    }
}
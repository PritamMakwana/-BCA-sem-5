package com.pritam36.task_1_fbf

import android.graphics.drawable.AnimationDrawable
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val start: Button = findViewById(R.id.btn_start)
        val stop: Button = findViewById(R.id.btn_stop)
        val bgimg: ImageView = findViewById(R.id.img_gangam)
        val mp: MediaPlayer = MediaPlayer.create(this,R.raw.gangam_style)
        start.setOnClickListener {
            val bg = bgimg.background as AnimationDrawable
            bg.start()
            mp.start()
        }
        stop.setOnClickListener {
            val bg = bgimg.background as AnimationDrawable
            bg.stop()
            mp.pause()
        }
    }
}
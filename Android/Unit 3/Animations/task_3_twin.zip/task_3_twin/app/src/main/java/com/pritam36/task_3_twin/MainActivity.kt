package com.pritam36.task_3_twin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val sun =  findViewById<ImageView>(R.id.sun)
        val clock = findViewById<ImageView>(R.id.clock)
        val hour = findViewById<ImageView>(R.id.hour)
        val sunRise = AnimationUtils.loadAnimation(this, R.anim.sun_rise)
        val clockTurn = AnimationUtils.loadAnimation(this, R.anim.clock_turn)
        val hourTurn = AnimationUtils.loadAnimation(this, R.anim.hour_turn)
        sun.startAnimation(sunRise)
        clock.startAnimation(clockTurn)
        hour.startAnimation(hourTurn)
    }
}
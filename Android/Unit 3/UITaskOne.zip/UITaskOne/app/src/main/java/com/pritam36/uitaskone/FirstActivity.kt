package com.pritam36.uitaskone

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        supportActionBar?.hide()

        val btn_acc: Button = findViewById(R.id.btn_acc)

        btn_acc.setOnClickListener(){
            val myintent = Intent(applicationContext, SecondActivity::class.java)
            startActivity(myintent)
        }
    }
}
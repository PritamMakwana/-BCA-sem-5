package com.pritam36.uitaskone

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ThridActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thrid)

        supportActionBar?.hide()

        val btn_back: Button = findViewById(R.id.btn_back)

        btn_back.setOnClickListener(){
            val myintent = Intent(applicationContext, FirstActivity::class.java)
            startActivity(myintent)
        }

    }
}
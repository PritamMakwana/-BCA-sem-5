package com.pritam36.uitaskone

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SecondActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        supportActionBar?.hide()

        val btn_sing_up: Button = findViewById(R.id.btn_sing_iu)

        btn_sing_up.setOnClickListener(){
            val myintent = Intent(applicationContext, ThridActivity::class.java)
            startActivity(myintent)
        }

    }
}
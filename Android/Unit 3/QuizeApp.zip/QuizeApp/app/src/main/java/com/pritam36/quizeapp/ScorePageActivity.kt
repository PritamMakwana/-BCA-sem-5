package com.pritam36.quizeapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.pritam36.quizeapp.R.*

class ScorePageActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_score_page)

        supportActionBar?.hide()


        val btn_home_back: Button = findViewById(id.btn_home_back)

        btn_home_back.setOnClickListener(){
            val myintent = Intent(applicationContext,HomeActivity::class.java)
            startActivity(myintent)
        }
    }
}
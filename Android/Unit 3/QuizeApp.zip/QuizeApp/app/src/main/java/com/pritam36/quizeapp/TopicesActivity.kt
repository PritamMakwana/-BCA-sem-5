package com.pritam36.quizeapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class TopicesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_topices)

        supportActionBar?.hide()

        val img_back_home:ImageView = findViewById(R.id.img_back_home)

        img_back_home.setOnClickListener(){
            val myintent = Intent(applicationContext, HomeActivity::class.java)
            startActivity(myintent)
        }

        val btn_back_topices:Button = findViewById(R.id.btn_topices_next)

        btn_back_topices.setOnClickListener(){
            val myintent = Intent(applicationContext, QuizPageActivity::class.java)
            startActivity(myintent)
        }

    }
}
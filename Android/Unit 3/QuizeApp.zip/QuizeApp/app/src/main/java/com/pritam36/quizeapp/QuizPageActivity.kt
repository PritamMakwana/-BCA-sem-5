package com.pritam36.quizeapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class QuizPageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_page)

        supportActionBar?.hide()

        val btn_quiz_next: Button = findViewById(R.id.btn_quizepage_next)

        btn_quiz_next.setOnClickListener(){
            val myintent = Intent(applicationContext, ScorePageActivity::class.java)
            startActivity(myintent)
        }


    }
}
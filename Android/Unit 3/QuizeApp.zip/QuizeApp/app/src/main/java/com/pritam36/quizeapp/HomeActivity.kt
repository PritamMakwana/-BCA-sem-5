package com.pritam36.quizeapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        supportActionBar?.hide()

        val btn_next_topices:Button = findViewById(R.id.btn_home_next)

        btn_next_topices.setOnClickListener(){
            val myintent = Intent(applicationContext, TopicesActivity::class.java)
            startActivity(myintent)
        }

    }
}
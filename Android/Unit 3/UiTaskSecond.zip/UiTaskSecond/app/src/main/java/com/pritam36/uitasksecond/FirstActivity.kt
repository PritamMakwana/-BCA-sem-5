package com.pritam36.uitasksecond

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class FirstActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.first_main)

        supportActionBar?.hide()

        val btn_quize_page: TextView = findViewById(R.id.btn_quize_page)

        btn_quize_page.setOnClickListener(){
            val myintent = Intent(applicationContext, SecondActivity::class.java)
            startActivity(myintent)
        }

    }
}
package com.pritam36.uitasksecond

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        supportActionBar?.hide()

        val btn_next_score_page: Button = findViewById(R.id.btn_next_score_page)

        btn_next_score_page.setOnClickListener(){
            val myintent = Intent(applicationContext, ScoreActivity::class.java)
            startActivity(myintent)
        }

    }
}
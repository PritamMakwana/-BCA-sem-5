package com.pritam36.uitasksecond

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class ScoreActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score)
        supportActionBar?.hide()

        val btn_home: ImageView = findViewById(R.id.btn_home)

        btn_home.setOnClickListener(){
            val myintent = Intent(applicationContext, FirstActivity::class.java)
            startActivity(myintent)
        }
    }
}
fun main() {

    for (i in 1.rangeTo(5)) {
        println(i)
    }
}
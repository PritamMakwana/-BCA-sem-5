fun main() {
    val lst = listOf("apple", "banana", "watermelon", "chiku")
    println(lst)
    // lst.add() // will get error
}
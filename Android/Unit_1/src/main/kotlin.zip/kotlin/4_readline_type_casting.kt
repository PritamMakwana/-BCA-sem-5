import java.util.*

fun main(){
val read = Scanner(System.`in`)

    println("Enter your name")
    var name =readLine()
    println("Enter your age")
    var age = read.nextInt()

    println("Name : "+name)
    println("Age : "+age)
}
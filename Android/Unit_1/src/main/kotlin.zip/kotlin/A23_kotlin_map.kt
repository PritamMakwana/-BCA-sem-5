fun main(){
    val theMap = mapOf("apple" to 1, "banana" to 2, "watermelon" to 3, "chiku" to 4)
    println(theMap)
    // theMap.add() // will get error
}
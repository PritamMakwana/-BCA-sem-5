fun main() {
    var i = 1
    while (i <= 5) {
        println(i)
        i++
    }
}
fun emp(){
    println("employee is very lazy")
}
fun main(){
    emp()
}
fun main(){
    repeat(3) {
        println("Hello")
    }
}
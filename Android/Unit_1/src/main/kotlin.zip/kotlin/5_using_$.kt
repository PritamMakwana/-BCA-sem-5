fun main(){
    var n = 10
    println("The value of n is $n")
}
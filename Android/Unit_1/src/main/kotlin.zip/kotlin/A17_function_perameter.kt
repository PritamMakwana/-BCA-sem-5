fun emp(nm : String){
    println("employee name is : "+ nm)
}
fun main(){
    emp("pritam")
}
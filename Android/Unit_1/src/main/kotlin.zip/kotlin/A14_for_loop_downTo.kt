fun main(){
    for (i in 5.downTo(1)) {
        println(i)
    }
}
fun main() {
    val theSet = setOf("apple", "banana", "watermelon", "chiku")
    println(theSet)
    //theSet.add // will get error
}
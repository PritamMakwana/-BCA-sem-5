fun main(){
    val a = 10
    var b = 20
    println("befor a = $a b = $b")
    //a = 30 error
    b = 30
    println("after a = $a b = $b")
}
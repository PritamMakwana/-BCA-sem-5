fun main(){
    val MutableLst = mutableListOf("apple", "banana", "watermelon", "chiku")
    println(MutableLst)
    MutableLst.add(0, "orages")
    MutableLst.add("coconet")
    println("After adding in list : "+ MutableLst)
}
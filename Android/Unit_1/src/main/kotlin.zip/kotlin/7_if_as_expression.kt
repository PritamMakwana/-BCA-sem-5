fun main(){
    val number = -10
    val result = if (number > 0) {
        "Positive number"
    } else {
        "Negative number"
    }
    println(result)
}
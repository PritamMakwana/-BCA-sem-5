fun main(){
    for (i in 1..10 step 2) {
        println(i)
    }
}
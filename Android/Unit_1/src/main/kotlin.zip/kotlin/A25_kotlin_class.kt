class myClass {
    fun enjoy() {
        print("this is class in function")
    }
}
fun main() {
    val obj = myClass()
    obj.enjoy()
}
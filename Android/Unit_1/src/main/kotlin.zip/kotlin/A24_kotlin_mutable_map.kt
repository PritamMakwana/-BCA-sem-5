fun main(){
    val theMutableMap = mutableMapOf("apple" to 1, "banana" to 2, "watermelon" to 3, "chiku" to 4)
    println(theMutableMap)
    theMutableMap.put("coconet", 5)
    println("After adding value in map : "+theMutableMap)
}
fun xman():String{
    return "Hello kotlin"
}
fun main(){
    println(xman())
}

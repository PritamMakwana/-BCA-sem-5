fun main() {
    var i = 1;
    do {
        println(i)
        i++
    }
    while (i <= 5)
}
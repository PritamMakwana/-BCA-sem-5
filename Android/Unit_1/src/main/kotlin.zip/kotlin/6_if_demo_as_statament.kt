fun main(){
    var a = 0
    if (a > 0){
        println("$a is positive number")
    }
    else if(a < 0){
        println("$a is negative number")
    }
    else{
        println("$a is equal to zero")
    }
}
fun main(){
    val theMutableSet = mutableSetOf("apple", "banana", "watermelon", "chiku")
    println(theMutableSet)
    theMutableSet.add("coconet")
    println("After adding  in set : "+theMutableSet)
}